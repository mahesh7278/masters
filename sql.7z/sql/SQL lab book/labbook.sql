
1.3
create database Training

create table Customer ( Customerid int Unique NOT NULL,
							   CustomerName varchar(20) NOT NULL,
							   Address1 varchar(30),
							   Address2 varchar(30),
							   ContactNumber varchar(12) NOT NULL,
							   PostalCode varchar(12),
							   )
					
create table Employees ( EmployeeId int NOT NULL Primary Key,
						 Name Nvarchar (255) NOT NULL,
						 );

create table Contractors ( ContractorId int NOT NULL Primary Key,
						   Name Nvarchar(255) NOT NULL
						  );
select * from customers
Use Training;

create table dbo.TestRethrow ( ID int Primary Key);

create type Region
from varchar(15)

create default df_region as 'NA'
Go
EXEC sp_bindefault df_region, 'Region'

 ALTER TABLE Customer
 ADD Customer_Region Region 

  ALTER TABLE Customer
 ADD Gender char(1) NULL
 
 ALTER TABLE Customer
 ADD CONSTRAINT ck_gender Check (Gender LIKE '[MFT]')

 create table Orders ( OrdersId int NOT NULL identity(1000,1), 
						CustomerId int NOT NULL, 
						OrdersDate datetime, 
						Order_state char(1) Constraint ck_ord Check (Order_state LIKE '[PC]'),
						);
						select* from customer

alter table dbo.Orders
add constraint cust_orders
Foreign Key (CustomerId)
References dbo.Customer(CustomerId)

Use Training
create sequence IdSequence as INT
start with 10000
increment by 1;


Use Training

Insert into Employees (EmployeeId,Name)
Values (Next Value for IdSequence, 'Shashank')

Insert into Contractors (ContractorId,Name)
Values(Next Value for IdSequence, 'Aditya')	

Select * from Employees
Select * from Contractors


1.4
create table Design_Master( Design_code int Primary Key NOT NULL,
							Design_name varchar(50)
							);

create table Department_Master (Dept_Code int Primary Key NOT NULL,
								Dept_name varchar(50));

create table Student_Master (   Student_Code int Primary Key NOT NULL,
								Student_name varchar(50) NOT NULL,
								Dept_Code int ,
								constraint fk_dptcode
								Foreign Key (Dept_Code)
								References dbo.Department_Master(Dept_Code),
								Student_dob datetime,
								Student_Address varchar(240)
								);

create table Student_Marks ( Student_Code int ,
							constraint fk_stcode
								Foreign Key (Student_Code)
								References dbo.Student_Master(Student_Code),
								Student_Year int NOT NULL,
								Subject1 int,
								Subject2 int,
								Subject3 int);

create table Staff_Master(Staff_Code int Primary Key NOT NULL,
							Staff_Name varchar(50) NOT NULL,
							Design_code int,
							constraint fk_dsgcode
							Foreign Key (Design_code)
							References dbo.Design_Master(Design_Code),
							Dept_Code int,
							constraint fk_dtcode
							Foreign Key (Dept_Code)
							References dbo.Department_Master(Dept_Code),
							HireDate Datetime,
							Staf_dob Datetime,
							Staff_address varchar(240),
							Mgr_code int,
							Staff_sal decimal(10,2)
							);

create table Book_Master (Book_Code int Primary Key NOT NULL,
						  Book_Name varchar(50) NOT NULL,
						  Book_pub_year int,
						  Book_pub_author varchar(50) NOT NULL,
						  Book_category varchar(10)
						  );

create table Book_Transaction ( Book_Code int,
                             constraint fk_bkcode
							Foreign Key (Book_Code)
							References dbo.Book_Master(Book_Code),
							Student_Code int,
							constraint fk_st1code
							Foreign Key (Student_Code)
							References dbo.Student_Master(Student_Code),
							Staff_Code int,
							constraint fk_stfcode
							Foreign Key (Staff_Code)
							References dbo.Staff_Master(Staff_Code),
							Book_Issue_Date Datetime NOT NULL,
							Book_Expected_Return_Date Datetime NOT NULL,
							Book_Actual_Return_Date Datetime NULL
							);

  1.4 Solutions
 
 1. Select Student_Code,Student_Name,Dept_Code from Student_Master

 2. Select Staff_Code,Staff_Name,Dept_Code from Staff_Master

 3. Select Staff_Name,Staff_sal,Dept_Code from Staff_Master 
    where Staff_Code IN (20,30,40)
 
 4. Alter table Student_Marks
    Add Total_Marks AS (Subject1+Subject2+Subject3)
	
	Select Student_Code,Subject1,Subject2,Subject3,Total_Marks 
	from Student_Marks order by Total_Marks desc

5. Select Book_Name from Book_Master
   where Book_Name LIKE '%An'

6 select departmentcode
   from students
   where year(JoiningDate)=1992

7 SELECT firstName,DATEPART(MM,BirthDate) as Month ,DATEPART(DD,BirthDate) as Date,DATEPART(YYYY,BirthDate) as Year from Employees
    where datename(DW,BirthDate) IN 'Sunday' OR 'Saturday'

8 select StaffCode,StaffName,DeptCode,DateOfJoining,NoOfYearsInTheCompany From Employee

9 select departmentcode
   from students
   where year(JoiningDate)<2000

10 select Student_Name,Department_Code,DOB from Student where DOB between 'January 1, 1981' AND 'March 31,1983'

11 select Student_Id from student where subject2 is null

1.5

1  select StaffName,DepartmentCode,DepartmentName,Salary from Staff 
     Inner Join Department
     on Staff.StaffId=Department.StaffId
      where Salary>20000

2  select StaffName,DepartmentCode,DepartmentName from Staff
     Inner Join Department
     on Staff.StaffId=Department.StaffId
     where DepartmentCode != 10

3  select BookName,Issued AS 'No of times issued' from Book where BookName IN 'Let us C' 'Linux Internals'
    
4  select Subjects,Marks from Students where DATEPART(YYYY,JoinDate)=DATEPART(YYYY,GET DATE()) - 1

5 n select S.StaffCode,S.StaffName,M.StaffCode AS ManagerCode,M.StaffName AS ManagerName
   from Staff S
   Inner Join Staff M ON S.StaffCode=M.StaffCode

6  select StaffName,HireDate,datename(DW,HireDate) as Day from staff 
   order by Day
     
7  select StaffCode,StaffName,DepartmentName from Staff
   Inner join Department 
   On Staff.StaffCode =  Department.Staffcode
   where IssuedBook > 1

8 Select StudentCode from Student where subject1 =
(select max(subject1) from Student) 
    

9 Select StudentCode,StudentName from Student where subject1 =
(select max(subject1) from Student)

  
10 select BookName,Bookcode from Library where IssuedBookCode
exist 
(select IssuedBookCode from Library where IssuedBook = 0)

11. Select Student_Master.Student_Code,Staff_Master.Staff_Code 
    from Student_Master, Staff_Master
	where Staff_Code IN (20,30,40)

12. Select Student_Code, Total_Marks
    from Student_Marks 
	where Total_Marks = 0 
	And Student_Year like '2019'

13. Select Student_Code 
    from Book_Transaction
	where Book_Issue_Date like 'NA'

14. create table Customers ( Customerid varchar(10) Unique NOT NULL,
							   CustomerName varchar(50) NOT NULL,
							   Address1 varchar(30),
							   Address2 varchar(30),
							   ContactNumber varchar(12) NOT NULL,
							   PostalCode varchar(12),
							   Region varchar(40) NULL,
							   Gender varchar(50) NULL
							   )
Select * from Customers
Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode) 
values ('ALFKI','AlfredsFutterkiste Obere Str.57 ','Berlin','Germany','030-0074321', 12209);

Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode)
values('ANATR', 'Ana Trujillo Emparedados y helados' ,
'Avda. de la Constituci �n 2222' ,
'M�xico D.F.,Mexico',
'(5)555-4729', 
5021);

Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode)
values ('ANTON', 'Antonio Moreno Taquer�a' ,
'Matadero s  2312', 
'M�xico D.F.,Mexico' ,
'(555)5-3932' ,
5023)

Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode)
values ('AROUT', 'Around the Horn', '120 Hanover Sq.', 
'London,UK','(171)555-778',
'WA11DP')


Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode)
values ('BERGS', 'Berglundssnabbk� p ',
'Berguvsv �gen  8' ,
'Lule�,Sweden', 0921123465, 
'S-958 22') 

Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode)
values ('BLAUS',' Blauer See Delikatessen',
'Forsterstr . 57 ',
'Mannheim,Germany' ,
'0621-0846', 
68306)


Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode)
values ('BLONP' ,'Blondesddslp�re et fils ',
'24, place Kl�ber', 
'Strasbourg,France' ,
'88.60.1 5.31' ,
67000)

Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode,Region)
values ('BOLID', 'B�lidoComidaspre paradas ',
'C/Araquil,67', 
'Madrid,Spain', '(91)5552282' ,
28023 ,'EU')

Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode)
values ( 'BONAP' ,'Bon app' ,'12, rue des Bouchers ',
'Marseille,France' ,
'91.24.4 5.40 ',
13008)

Insert into Customers(Customerid,CustomerName,Address1,Address2,ContactNumber,PostalCode,Region)
values ('BOTTM', 'Bottom-Dollar Markets' ,
'23 Tsawasse n Blvd.' ,
'Tsawassen,Canada', 
'(604)5554729 ',
'T2F 8M4' ,
'BC' )

 15. update Customers 
     Set ContactNumber = Replace (ContactNumber,'(5)555-4729','(604)3332345')
	
 16.  update Customers 
      Set Address1 = Replace (Address1,'23 Tsawasse n Blvd.','19/2 12thBlock,Spring Fields.');
	  update Customers 
	  Set Address2 = Replace ( Address2,'Tsawassen,Canada','Ireland  - UK');
	  update Customers 
	  Set Region = Replace ( Region, 'BC','EU');

 17. create table Orders1 ( OrdersId1 int NOT NULL identity(1000,1), 
						CustomerId1 varchar(20) NOT NULL, 
						OrdersDate1 datetime, 
						Order_state1 char(1) Constraint ck_ord1 Check (Order_state1 LIKE '[PC]'),
						);
 
 
     insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('AROUT', '4-Jul-96', 'P' )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('ALFKI', '5-Jul-96', 'C'  )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('BLONP', '8-Jul-96', 'P'  )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('ANTON' ,'8-Jul-96', 'P'  )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('ANTON' ,'9-Jul-96' ,'P'  )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('BOTTM', '10-Jul-96', 'C'  )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('BONAP', '11-Jul-96', 'P ' )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('ANATR' ,'12-Jul-96' ,'P' )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('BLAUS' ,'15-Jul-96' ,'C'  )
	 insert into Orders1(CustomerId1,OrdersDate1,Order_State1)
	 values ('HILAA' ,'16-Jul-96', 'P' )

	 Select * from Orders1

18. Delete from Orders1
	where Order_State1 = 'C'
    
19. truncate table Orders1

20. Update table Orders1
	set Order_state1 = replace (Order_state1,'P','C')
	where OrdersDate1 like <15-Jul-96 

1.6

1.USE Training

CREATE UNIQUE INDEX ix_deptMaster
ON Department_Master(Dept_Name)

2.INSERT INTO Department_Master
VALUES (100, 'Home Science');

INSERT INTO Department_Master
VALUES (200, 'Home Science');

Cannot insert duplicate key row in object 'dbo.Department_Master' with unique index 'ix_deptMaster'. The duplicate key value is (Home Science).
The statement has been terminated.


INSERT INTO Department_Master
VALUES (300,NULL);


INSERT INTO Department_Master
VALUES (400, NULL);



Cannot insert duplicate key row in object 'dbo.Department_Master' with unique index 'ix_deptMaster'. The duplicate key value is (<NULL>).
The statement has been terminated.




3.CREATE NONCLUSTERED INDEX ix_BookTrans
ON Book_Transaction
(Book_code,Book_Issue_Date)

4.sp_helpindex Book_Transaction
	
	
5.	Create view StaffDetails_view
	AS Select Staff_Code,Staff_Name,Dept_name,Design_code,Staff_sal 
	from Staff_Master,Department_Master
6.  VALUES Cannot be inserted into a view table.

7. CREATE NONCLUSTERED INDEX idx_production_notnull 
	ON Production.BillOfMaterials(ProductID) 
	WHERE EndDate IS NOT NULL

8.  Select Staff_Name from StaffDetails_view
	where HireDate like '%June%'

10.  Alter table Employees
	Add Constraint U_empid unique nonclustered(EmployeeID);


1.7

1.7.1

create proc Update_Salary
@Staff_code int
AS
Begin
Declare @last_Sal money
set @last_Sal=(select Staff_Exp from Staff_Master where Staff_code=@Staff_code)
declare @Exp int
set @Exp=(select Staff_Exp from Staff_Master where Staff_code=@Staff_code)

If @Exp<2
Begin
Select Staff_Sal from Staff_Master where Staff_Code=@Staff_code
End

Else if (@Exp>=2 and @Exp<=5)
Begin
Update Staff_Master
set @Staff_Sal=@last_Sal+(@last_Sal*0.2)
where Staff_code=@Staff_code;
End

Else if @Exp>5
Begin
Update Staff_Master
set @Staff_Sal=@last_Sal+(@last_Sal*0.25)
where Staff_code=@Staff_code;
End

Update Staff_Master_Back
set @Staff_Sal=@last_Sal
where Staff_Code=@Staff_code;

Select Staff_Sal from Staff_Master where Staff_code=@Staff_code;
 

1.7.5


create proc testproc
@studentcode int not null
@marks int 
as
begin
declare @name varchar , 
declare @returnvar int ,
declare @flag int
if exits (select studentcode from studentmaster where studentcode= @student)
begin
if not exists (select studentmarks from studentmarks where studentcode= @studentcode)
begin
set @name = select name from studentmaster where studentcode= @studentcode
set @flag = insert into studentmarks values (@studentcode,@name,extract(year from getdate()),@marks)\
if @flag=1
@returnvar=0
else
 @returnvar=-1
 end
 else
 begin
 set @returnvar=-1
 end
 end
 else
 begin
 @retunvar=-1
 end




1.7.3


create proc usp_exp
@staffcode int,
@newsalary int output
as 
begin
insert int staff_master_back select * from staff_master where staffcode = @staffcode
update staff_master
set salary=
	 case 
		when exp<2 then salary
		when(exp>=2 and exp<=5)then salary *1.2
		when (exp>=5 )then salary *1.25
		end
		where staffcode=@staffcode
		set newsalary=(select from staff_master where staffcode = @staffcode)
		return @staffcode
end


1.7.4


create proc procedurename
@bookcode int not null
as
begin
select code, name,issuedate,designation,retrundate
from tablename
where bookcode = @bookcodeand 
and hasReturned =0
and returndate > getdate()
end


1.7.2


create proc testproc
@staffcode int,
@bookcode int,
@returndate datetime output

as
begin
set @returndate = dateadd(day, 10,getDate())
if (datename(weekday,@returndate)in(N 'Saturday', N 'Sunday'))
	set @returndate = dateadd(week,datediff(week,0,getdate())
	insert into yourtable values(#bookcode,getDate(),returndate)
	select @returndate
	end

	
2.1
1. List the empno, name and Department No of the employees who have got experience of more than 18 years. 

SELECT empno, name,Department No from Employee
Where experience > 18;

2. Display the name and salary of the staff. Salary should be represented as X. Each X represents a 1000 in salary. It is assumed that a staff�s salary to be multiples of 1000  , for example a salary of 5000 is represented as XXXXX 
 
Sample Output 
 
JOHN  10000  XXXXXXXXXX ALLEN  12000   XXXXXXXXXXXX 
 
CREATE PROC usp_Salary ( @Name VARCHAR(20), @Salary MONEY,@a INT,@i INT,@x varchar(20) )
SET @Name ='Sairam';
SET @Salary = 5000;

AS 
BEGIN

@a=@Salary/1000;
@x='X';

for(i=0;i<=@a;i++)
{
 SELECT @x;
}
END

3.List out all the book code  and library member codes  whose  return is still pending 

    SELECT book_code, library_codes from libraray
    where Status Like '%pending%' 

4.List all the staff�s whose birthday falls on the current month 
 
    SELECT * from staff
    where birthday =  (select month where getmonth() = 05  ) 

5.How many books are stocked in the library? 

    SELECT count(books) As Books_in_Stock from libraray
    where books is NOT NUll; 
 
6.How many books are there for topics   Physics and Chemistry? 

    SELECT count(books) As Totalbooks from libraray
    where subjects like 'physics' and 'Chemistry';

7.How many members are expected to return their books today? 

    SELECT count(members) from library
    where (select books from librabry where return date = getdate ());

8. Display the Highest, Lowest, Total & Average salary of all staff. Label the columns Maximum, Minimum, Total and Average respectively. Round the result to nearest whole number

  SELECT MAX(salary)As Maximum , MIN(salary) AS Minimum ,Total(Salary) As Total,AVG(salary)AS Average from employee where 

9.How many staffs are managers�? 

  SELECT COUNT(staff) where staff like '%Manager%' ;


10. List out year wise total students passed. The report should be as given below.
 A student is considered to be passed only when he scores 60 and above in all 3 subjects individually  Year    No of students passed  
 

  CREATE PROCEDURE usp_ProductCountByCategory ( @Physics INT out , @Chemistry INT out ,@maths Int out) 
  Declare @ Totalint ,@P int ,@C int,@m int;

  AS

   BEGIN 
     
      set  @P = @Physics ;
      set  @C = @Chemistry ;
      set  @m = @maths ;

    IF @P > 60 AND @c > 60 AND @M >60   

   return select count(students As PassedOut) from students;

   ENDIF

  END


11. List out all the departments which is having a headcount of more than 10 ?
 

  select departments from employee where (count(departments) > 10);


12.List the total cost of library inventory ( sum of prices of all books )

  select TOTAL(prize) AS Toatal_Cost from library


13. List  out category wise count of books costing more than Rs 1000 /- 


  select distinct(books) form library  where prize > 1000

14. How many students have joined in Physics dept (dept code is 10) last year?


  select count(students) from students where dept = 'physics' and deptcode = 10 ; 





2.3 Create a Filtered Index HumanResources.Employee table present in the AdventureWorks database for the column EmployeeID. The index should cover all the queries that uses EmployeeID for its search & that select only rows with �Marketing Manager� for Title column. 



   EXECUTE HumanResources.uspGetEmployeesTest2 N'Ackerman', N'Pilar';
  -- 
  Or 
  EXEC HumanResources.uspGetEmployeesTest2 @LastName = N'Ackerman', @FirstName = N'Pilar'; 
   GO -- 
 Or
  EXECUTE HumanResources.uspGetEmployeesTest2 @FirstName = N'Pilar', @LastName = N'Ackerman';
  GO 