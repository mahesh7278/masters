function calculateSalary()
        {
            var id = document.getElementById("txtID").value;
            var name = document.getElementById("txtName").value;
            var doj = document.getElementById("txtDOJ").value;
            var phone = document.getElementById("txtPhone").value;
            var salary = parseInt(document.getElementById("txtSalary").value);

            var gross = salary + parseInt(salary * 0.15) + parseInt(salary * 0.20) + 1600;
            var deduction = 200 + parseInt(salary * 0.12) + parseInt(((salary * 12 - 150000) * 0.10)/12)
            var net = gross - deduction;

            alert("Employee ID : " + id +
                "\nEmployee Name : " + name +
                "\nDate of Joining : " + doj +
                "\nPhone Number : " + phone +
                "\nSalary : " + salary + 
                "\nGross Salary : " + gross + 
                "\nNet Salary : " + net);
        }